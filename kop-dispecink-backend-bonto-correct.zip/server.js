const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());
app.use('/sounds', express.static(path.join(__dirname, 'sounds')));

const units = new Map(); // unitId -> { id, name, members: Map(memberId -> member) }
const members = new Map(); // memberId -> { id, name, unitId, token, socketId }
const calls = new Map(); // callId -> call data
const dispatchers = new Map(); // dispatcherId -> { id, password, name }

// Create dispatcher account
app.post('/api/dispatcher/create', (req, res) => {
  const { password, name } = req.body;
  if (!password) return res.status(400).json({ error: 'Heslo vyžadováno' });
  
  const dispatcherId = uuidv4();
  dispatchers.set(dispatcherId, { id: dispatcherId, password, name: name || 'Dispečer' });
  res.json({ dispatcherId, success: true });
});

// Dispatcher login
app.post('/api/dispatcher/login', (req, res) => {
  const { password } = req.body;
  
  for (let [id, disp] of dispatchers) {
    if (disp.password === password) {
      return res.json({ success: true, dispatcherId: id, name: disp.name });
    }
  }
  res.status(401).json({ error: 'Špatné heslo' });
});

// Create/join unit
app.post('/api/unit/create', (req, res) => {
  const { unitName, dispatcherId } = req.body;
  const unitId = uuidv4().substring(0, 8).toUpperCase();
  
  units.set(unitId, {
    id: unitId,
    name: unitName,
    dispatcherId,
    members: new Map()
  });
  
  res.json({ unitId, unitName });
});

app.get('/api/units', (req, res) => {
  const unitList = Array.from(units.values()).map(u => ({
    id: u.id,
    name: u.name,
    memberCount: u.members.size
  }));
  res.json({ units: unitList });
});

// Member join unit
app.post('/api/unit/join', (req, res) => {
  const { unitId, memberName } = req.body;
  const unit = units.get(unitId);
  
  if (!unit) {
    return res.status(404).json({ error: 'Jednotka nenalezena' });
  }
  
  const memberId = uuidv4();
  const token = uuidv4();
  
  const member = {
    id: memberId,
    name: memberName,
    unitId,
    token,
    socketId: null
  };
  
  members.set(memberId, member);
  unit.members.set(memberId, member);
  
  res.json({ memberId, token, unitId, unitName: unit.name });
});

// Dispatcher triggers alarm for selected units
app.post('/api/dispatch/alarm', (req, res) => {
  const { dispatcherId, unitIds, callType, description, location } = req.body;
  
  if (!dispatcherId) {
    return res.status(401).json({ error: 'Neautorizováno' });
  }
  
  const callId = uuidv4();
  const targets = unitIds && unitIds.length > 0 ? unitIds : Array.from(units.keys());
  
  targets.forEach(unitId => {
    const unit = units.get(unitId);
    if (unit) {
      const call = {
        id: callId,
        unitId,
        unitName: unit.name,
        callType: callType || 'Výjezd',
        description: description || '',
        location: location || '',
        timestamp: new Date().toISOString(),
        active: true
      };
      
      unit.members.forEach(member => {
        if (member.socketId) {
          io.to(member.socketId).emit('alarm', call);
        }
      });
      io.to(`unit:${unitId}`).emit('alarm', call);
    }
  });
  
  res.json({ success: true, callId, unitsCalled: targets.length });
});

app.get('/api/unit/:unitId/members', (req, res) => {
  const unit = units.get(req.params.unitId);
  if (!unit) return res.status(404).json({ error: 'Jednotka nenalezena' });
  
  const memberList = Array.from(unit.members.values()).map(m => ({
    id: m.id,
    name: m.name,
    online: !!m.socketId
  }));
  
  res.json({ members: memberList });
});

io.on('connection', (socket) => {
  socket.on('register', (data) => {
    const { memberId, token, unitId } = data;
    const member = members.get(memberId);
    
    if (member && member.token === token) {
      member.socketId = socket.id;
      socket.join(`unit:${unitId}`);
      socket.join(`member:${memberId}`);
    }
  });
  
  socket.on('register_dispatcher', (data) => {
    const { dispatcherId } = data;
    socket.join(`dispatcher:${dispatcherId}`);
  });
  
  socket.on('disconnect', () => {
    for (let [memberId, member] of members) {
      if (member.socketId === socket.id) {
        member.socketId = null;
        break;
      }
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`KOP Dispečink server běží na portu ${PORT}`);
});

// Pravidelná zkouška sirén - do soboty 31.10.2026
function scheduleSirenTest() {
  const now = new Date();
  const day = now.getDay(); // 0 = neděle, 1 = pondělí, 2 = úterý, 6 = sobota
  const hour = now.getHours();
  const minute = now.getMinutes();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const date = now.getDate();
  
  // Do 31.10.2026
  const isBeforeDeadline = !(year > 2026 || (year === 2026 && month > 10) || (year === 2026 && month === 10 && date > 31));
  
  if (!isBeforeDeadline) return;
  
  // Sobota 13:00
  if (day === 6 && hour === 13 && minute === 0) {
    sendTestAlarm();
    return;
  }
  
  // Úterý 15:45 (do 31.10.2026)
  if (day === 2 && hour === 15 && minute === 45) {
    sendTestAlarm();
  }
}

function sendTestAlarm() {
  console.log('Spouštím zkoušku sirén');
  
  units.forEach((unit, unitId) => {
    const testCall = {
      id: uuidv4(),
      unitId,
      unitName: unit.name,
      callType: 'ZKOUŠKA SIREN',
      description: 'Zkouška sirén',
      location: '',
      timestamp: new Date().toISOString(),
      isTest: true
    };
    
    unit.members.forEach(member => {
      if (member.socketId) {
        io.to(member.socketId).emit('alarm', testCall);
      }
    });
    io.to(`unit:${unitId}`).emit('alarm', testCall);
  });
}

setInterval(scheduleSirenTest, 60000);
